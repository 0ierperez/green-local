import { Header } from "@/components/header"
import { HeroSection } from "@/components/hero-section"
import { PillarsSection } from "@/components/pillars-section"
import { ImpactSection } from "@/components/impact-section"
import { TrustSection } from "@/components/trust-section"
import { HowItWorks } from "@/components/how-it-works"
import { Footer } from "@/components/footer"

export default function Home() {
  return (
    <main className="min-h-screen bg-background">
      <Header />
      <HeroSection />
      <PillarsSection />
      <ImpactSection />
      <HowItWorks />
      <TrustSection />
      <Footer />
    </main>
  )
}
