"use client"

import { motion } from "framer-motion"
import { Card, CardContent } from "@/components/ui/card"
import { CheckCircle, Leaf, Award, ShieldCheck } from "lucide-react"

const certifications = [
  {
    icon: Leaf,
    title: "Produktu Jasangarriak",
    description: "Tokiko ekoizpen eta ingurumen-inpaktu baxuko produktuak"
  },
  {
    icon: ShieldCheck,
    title: "Jatorri Gardena",
    description: "Produktu bakoitzaren jatorria eta ekoizpena egiaztatu"
  },
  {
    icon: Award,
    title: "Karbono Baxua",
    description: "0 km garraio jasangarriarekin banatuta"
  }
]

const testimonials = [
  {
    quote: "Green Local-i esker, nire denda digitalizatu ahal izan dut eta bezero berriak lortu ditut herritik kanpo.",
    author: "Maria L.",
    role: "Okindegia, Arrigorriaga"
  },
  {
    quote: "Orain badakit nire erosketak ingurumena zaintzen dutela. Produktuen gardentasuna zoragarria da.",
    author: "Andoni P.",
    role: "Bezeroa"
  },
  {
    quote: "Gure artisau produktuak herritar gehiagorengana heltzen dira orain. Plataforma oso erraza da erabiltzen.",
    author: "Iker G.",
    role: "Baserritar lokala"
  }
]

export function TrustSection() {
  return (
    <section id="konfiantza" className="py-20 lg:py-28 bg-secondary/30">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Green Local Seal */}
        <div className="mb-20">
          <div className="text-center max-w-3xl mx-auto mb-12">
            <motion.span 
              initial={{ opacity: 0 }}
              whileInView={{ opacity: 1 }}
              viewport={{ once: true }}
              className="inline-block text-sm font-medium text-primary mb-4"
            >
              Konfiantza
            </motion.span>
            <motion.h2 
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              className="text-3xl sm:text-4xl font-semibold text-foreground text-balance"
            >
              GreenLocal zigilua
            </motion.h2>
            <motion.p 
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: 0.1 }}
              className="mt-4 text-lg text-muted-foreground text-pretty"
            >
              Herriko denda jasangarriak ziurtatzeko zigilu berezia, 
              bezeroek gure balioak identifika ditzaten.
            </motion.p>
          </div>

          {/* Seal Visual */}
          <motion.div 
            initial={{ opacity: 0, scale: 0.9 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            className="flex justify-center mb-12"
          >
            <div className="relative">
              <div className="w-40 h-40 rounded-full bg-primary flex items-center justify-center shadow-2xl shadow-primary/30">
                <div className="w-32 h-32 rounded-full border-4 border-dashed border-primary-foreground/40 flex flex-col items-center justify-center">
                  <Leaf className="w-10 h-10 text-primary-foreground mb-1" />
                  <span className="text-primary-foreground font-bold text-sm">GREEN</span>
                  <span className="text-primary-foreground font-bold text-sm">LOCAL</span>
                </div>
              </div>
              <div className="absolute -top-2 -right-2 w-10 h-10 rounded-full bg-card border-2 border-primary flex items-center justify-center">
                <CheckCircle className="w-5 h-5 text-primary" />
              </div>
            </div>
          </motion.div>

          {/* Certification Features */}
          <div className="grid md:grid-cols-3 gap-6 max-w-4xl mx-auto">
            {certifications.map((cert, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
                className="text-center"
              >
                <div className="inline-flex items-center justify-center w-12 h-12 rounded-xl bg-primary/10 mb-4">
                  <cert.icon className="w-6 h-6 text-primary" />
                </div>
                <h3 className="text-lg font-semibold text-foreground mb-2">
                  {cert.title}
                </h3>
                <p className="text-sm text-muted-foreground">
                  {cert.description}
                </p>
              </motion.div>
            ))}
          </div>
        </div>

        {/* Testimonials */}
        <div>
          <div className="text-center max-w-3xl mx-auto mb-12">
            <motion.h3 
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              className="text-2xl sm:text-3xl font-semibold text-foreground text-balance"
            >
              Gure komunitateak esaten duena
            </motion.h3>
          </div>

          <div className="grid md:grid-cols-3 gap-6">
            {testimonials.map((testimonial, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
              >
                <Card className="h-full bg-card border-border hover:border-primary/30 transition-colors">
                  <CardContent className="p-6">
                    <div className="flex gap-1 mb-4">
                      {[...Array(5)].map((_, i) => (
                        <svg
                          key={i}
                          className="w-4 h-4 text-primary fill-primary"
                          viewBox="0 0 20 20"
                        >
                          <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                        </svg>
                      ))}
                    </div>
                    <blockquote className="text-foreground mb-4 leading-relaxed">
                      &ldquo;{testimonial.quote}&rdquo;
                    </blockquote>
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center">
                        <span className="text-sm font-semibold text-primary">
                          {testimonial.author.charAt(0)}
                        </span>
                      </div>
                      <div>
                        <p className="text-sm font-semibold text-foreground">
                          {testimonial.author}
                        </p>
                        <p className="text-xs text-muted-foreground">
                          {testimonial.role}
                        </p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </section>
  )
}
