"use client"

import { motion } from "framer-motion"
import { TrendingDown, Leaf, Users, Package } from "lucide-react"

const stats = [
  {
    icon: TrendingDown,
    value: "85%",
    label: "CO₂ murrizketa",
    description: "0 km kontsumoarekin"
  },
  {
    icon: Leaf,
    value: "12T",
    label: "Elikagai salbatuta",
    description: "Xahuketaren aurka"
  },
  {
    icon: Users,
    value: "350+",
    label: "Familia lagunduak",
    description: "Elikagaien Bankuaren bidez"
  },
  {
    icon: Package,
    value: "45+",
    label: "Tokiko dendak",
    description: "Sarean integratuta"
  }
]

export function ImpactSection() {
  return (
    <section id="inpaktua" className="py-20 lg:py-28 bg-primary text-primary-foreground relative overflow-hidden">
      {/* Background Pattern */}
      <div className="absolute inset-0 opacity-10">
        <div className="absolute top-0 left-1/4 w-64 h-64 rounded-full bg-white blur-3xl" />
        <div className="absolute bottom-0 right-1/4 w-96 h-96 rounded-full bg-white blur-3xl" />
      </div>

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <motion.span 
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true }}
            className="inline-block text-sm font-medium text-primary-foreground/80 mb-4"
          >
            Gure inpaktua
          </motion.span>
          <motion.h2 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-3xl sm:text-4xl font-semibold text-primary-foreground text-balance"
          >
            Datuekin neurtzen dugu aldaketa
          </motion.h2>
          <motion.p 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.1 }}
            className="mt-4 text-lg text-primary-foreground/80 text-pretty"
          >
            Kilometro 0ko kontsumoak ingurumenean eta komunitatean duen eragina.
          </motion.p>
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-6 lg:gap-8">
          {stats.map((stat, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
              className="text-center p-6 rounded-2xl bg-white/10 backdrop-blur-sm border border-white/20 hover:bg-white/15 transition-colors"
            >
              <div className="inline-flex items-center justify-center w-12 h-12 rounded-xl bg-white/20 mb-4">
                <stat.icon className="w-6 h-6 text-primary-foreground" />
              </div>
              <div className="text-4xl sm:text-5xl font-bold text-primary-foreground mb-2">
                {stat.value}
              </div>
              <div className="text-sm font-medium text-primary-foreground mb-1">
                {stat.label}
              </div>
              <div className="text-xs text-primary-foreground/70">
                {stat.description}
              </div>
            </motion.div>
          ))}
        </div>

        {/* Additional Info */}
        <motion.div 
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ delay: 0.4 }}
          className="mt-16 text-center"
        >
          <div className="inline-flex items-center gap-4 px-6 py-3 rounded-full bg-white/10 border border-white/20">
            <div className="flex items-center gap-2">
              <div className="w-2 h-2 rounded-full bg-green-300 animate-pulse" />
              <span className="text-sm text-primary-foreground/90">
                Datu errealak, Arrigorriagan
              </span>
            </div>
            <div className="w-px h-4 bg-white/30" />
            <span className="text-sm text-primary-foreground/70">
              2025-2026 ikasturtea
            </span>
          </div>
        </motion.div>
      </div>
    </section>
  )
}
