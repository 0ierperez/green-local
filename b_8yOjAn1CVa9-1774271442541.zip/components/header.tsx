"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Menu, X, Leaf } from "lucide-react"

export function Header() {
  const [isMenuOpen, setIsMenuOpen] = useState(false)

  return (
    <header className="fixed top-0 left-0 right-0 z-50 bg-background/95 backdrop-blur-sm border-b border-border">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 lg:h-20">
          {/* Logo */}
          <a href="#" className="flex items-center gap-2">
            <div className="w-10 h-10 rounded-full bg-primary flex items-center justify-center">
              <Leaf className="w-5 h-5 text-primary-foreground" />
            </div>
            <span className="text-xl font-semibold text-foreground tracking-tight">
              Green<span className="text-primary">Local</span>
            </span>
          </a>

          {/* Desktop Navigation */}
          <nav className="hidden lg:flex items-center gap-8">
            <a href="#pilareak" className="text-sm font-medium text-muted-foreground hover:text-foreground transition-colors">
              Pilareak
            </a>
            <a href="#inpaktua" className="text-sm font-medium text-muted-foreground hover:text-foreground transition-colors">
              Inpaktua
            </a>
            <a href="#nola" className="text-sm font-medium text-muted-foreground hover:text-foreground transition-colors">
              Nola funtzionatzen du
            </a>
            <a href="#konfiantza" className="text-sm font-medium text-muted-foreground hover:text-foreground transition-colors">
              Konfiantza
            </a>
          </nav>

          {/* CTA Button */}
          <div className="hidden lg:flex items-center gap-4">
            <Button variant="outline" size="sm" className="rounded-full">
              Saioa hasi
            </Button>
            <Button size="sm" className="rounded-full bg-primary hover:bg-primary/90">
              Hasi orain
            </Button>
          </div>

          {/* Mobile Menu Button */}
          <button 
            className="lg:hidden p-2"
            onClick={() => setIsMenuOpen(!isMenuOpen)}
            aria-label="Toggle menu"
          >
            {isMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>

        {/* Mobile Navigation */}
        {isMenuOpen && (
          <div className="lg:hidden py-4 border-t border-border">
            <nav className="flex flex-col gap-4">
              <a href="#pilareak" className="text-sm font-medium text-muted-foreground hover:text-foreground transition-colors">
                Pilareak
              </a>
              <a href="#inpaktua" className="text-sm font-medium text-muted-foreground hover:text-foreground transition-colors">
                Inpaktua
              </a>
              <a href="#nola" className="text-sm font-medium text-muted-foreground hover:text-foreground transition-colors">
                Nola funtzionatzen du
              </a>
              <a href="#konfiantza" className="text-sm font-medium text-muted-foreground hover:text-foreground transition-colors">
                Konfiantza
              </a>
              <div className="flex flex-col gap-2 pt-4 border-t border-border">
                <Button variant="outline" size="sm" className="rounded-full w-full">
                  Saioa hasi
                </Button>
                <Button size="sm" className="rounded-full bg-primary hover:bg-primary/90 w-full">
                  Hasi orain
                </Button>
              </div>
            </nav>
          </div>
        )}
      </div>
    </header>
  )
}
