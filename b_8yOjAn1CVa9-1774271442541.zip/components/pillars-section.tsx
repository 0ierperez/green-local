"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Globe, Eye, HeartHandshake } from "lucide-react"
import { motion } from "framer-motion"

const pillars = [
  {
    icon: Globe,
    title: "Plataforma Digitala",
    description: "Herriko denden produktu jasangarriak erosteko online gune bateratua. Etxeraino bidalketa jasangarriarekin edo dendan bertan jasotzeko aukerarekin (click & collect).",
    features: ["Marketplace bateratua", "Banaketa berdea", "Click & Collect"]
  },
  {
    icon: Eye,
    title: "Gardentasun Erradikala",
    description: "Produktu bakoitzaren jatorria, ekoizpen-prozesua eta karbono-aztarna ezagutu. Informazio osoarekin erabaki arduratsuak hartu.",
    features: ["Produktuaren jatorria", "Karbono-aztarna", "Ekoizpen prozesua"]
  },
  {
    icon: HeartHandshake,
    title: "Gizarte-Konpromisoa",
    description: "Iraungitze-datara hurbiltzen diren produktuak automatikoki detektatzen ditugu eta Bizkaiko Elikagaien Bankura bideratzen, elikagaien xahuketa murriztuz.",
    features: ["Elikagaien Bankua", "Zero xahuketa", "Elkartasuna"]
  }
]

const container = {
  hidden: { opacity: 0 },
  show: {
    opacity: 1,
    transition: {
      staggerChildren: 0.15
    }
  }
}

const item = {
  hidden: { opacity: 0, y: 20 },
  show: { opacity: 1, y: 0 }
}

export function PillarsSection() {
  return (
    <section id="pilareak" className="py-20 lg:py-28 bg-secondary/30">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <motion.span 
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true }}
            className="inline-block text-sm font-medium text-primary mb-4"
          >
            Gure oinarriak
          </motion.span>
          <motion.h2 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-3xl sm:text-4xl font-semibold text-foreground text-balance"
          >
            Hiru zutabe, helburu bakar bat
          </motion.h2>
          <motion.p 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.1 }}
            className="mt-4 text-lg text-muted-foreground text-pretty"
          >
            Tokiko ekonomia, jasangarritasuna eta gizarte-konpromisoa uztartzen ditugu 
            ekosistema digital berri bat sortzeko.
          </motion.p>
        </div>

        {/* Pillars Grid */}
        <motion.div 
          variants={container}
          initial="hidden"
          whileInView="show"
          viewport={{ once: true }}
          className="grid md:grid-cols-3 gap-6 lg:gap-8"
        >
          {pillars.map((pillar, index) => (
            <motion.div key={index} variants={item}>
              <Card className="h-full bg-card border-border hover:border-primary/30 transition-colors duration-300 group overflow-hidden">
                <CardHeader className="pb-4">
                  <div className="w-14 h-14 rounded-2xl bg-primary/10 flex items-center justify-center mb-4 group-hover:bg-primary/20 transition-colors">
                    <pillar.icon className="w-7 h-7 text-primary" />
                  </div>
                  <CardTitle className="text-xl font-semibold text-foreground">
                    {pillar.title}
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <CardDescription className="text-muted-foreground text-base leading-relaxed">
                    {pillar.description}
                  </CardDescription>
                  <div className="flex flex-wrap gap-2 pt-2">
                    {pillar.features.map((feature, featureIndex) => (
                      <span 
                        key={featureIndex}
                        className="inline-flex items-center px-3 py-1 rounded-full bg-primary/5 text-primary text-xs font-medium"
                      >
                        {feature}
                      </span>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </section>
  )
}
