"use client"

import { motion } from "framer-motion"
import { Search, ShoppingBag, Truck, Heart } from "lucide-react"

const steps = [
  {
    icon: Search,
    step: "01",
    title: "Arakatu",
    description: "Herriko denda guztietako produktuak bilatu eta konparatu plataforman."
  },
  {
    icon: ShoppingBag,
    step: "02",
    title: "Erosi",
    description: "Nahi dituzun produktuak aukeratu eta ordainketa segurua egin."
  },
  {
    icon: Truck,
    step: "03",
    title: "Jaso",
    description: "Etxean jaso (garraio jasangarriarekin) edo dendan bertan hartu."
  },
  {
    icon: Heart,
    step: "04",
    title: "Lagundu",
    description: "Zure erosketak tokiko ekonomia eta ingurumena babesten dute."
  }
]

export function HowItWorks() {
  return (
    <section id="nola" className="py-20 lg:py-28 bg-background">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <motion.span 
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true }}
            className="inline-block text-sm font-medium text-primary mb-4"
          >
            Prozesua
          </motion.span>
          <motion.h2 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-3xl sm:text-4xl font-semibold text-foreground text-balance"
          >
            Nola funtzionatzen du?
          </motion.h2>
          <motion.p 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.1 }}
            className="mt-4 text-lg text-muted-foreground text-pretty"
          >
            Lau urrats sinpletan zure herria lagundu dezakezu.
          </motion.p>
        </div>

        {/* Steps */}
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
          {steps.map((stepItem, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
              className="relative group"
            >
              {/* Connector Line (hidden on last item) */}
              {index < steps.length - 1 && (
                <div className="hidden lg:block absolute top-10 left-[60%] w-full h-px bg-border" />
              )}

              <div className="relative bg-card rounded-2xl p-6 border border-border hover:border-primary/30 transition-colors">
                {/* Step Number */}
                <div className="absolute -top-3 -right-3 w-8 h-8 rounded-full bg-primary text-primary-foreground text-xs font-bold flex items-center justify-center">
                  {stepItem.step}
                </div>

                {/* Icon */}
                <div className="w-14 h-14 rounded-2xl bg-primary/10 flex items-center justify-center mb-4 group-hover:bg-primary/20 transition-colors">
                  <stepItem.icon className="w-7 h-7 text-primary" />
                </div>

                {/* Content */}
                <h3 className="text-lg font-semibold text-foreground mb-2">
                  {stepItem.title}
                </h3>
                <p className="text-sm text-muted-foreground leading-relaxed">
                  {stepItem.description}
                </p>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  )
}
