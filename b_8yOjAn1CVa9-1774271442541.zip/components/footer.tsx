"use client"

import { Leaf, Instagram, Mail, MapPin, Phone } from "lucide-react"
import { Button } from "@/components/ui/button"

export function Footer() {
  return (
    <footer className="bg-foreground text-background">
      {/* CTA Section */}
      <div className="border-b border-background/10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
          <div className="text-center max-w-2xl mx-auto">
            <h2 className="text-2xl sm:text-3xl font-semibold text-background mb-4 text-balance">
              Prest zaude zure herria laguntzeko?
            </h2>
            <p className="text-background/70 mb-8">
              Bat egin Green Local komunitatearekin eta hasi tokiko eta jasangarriko kontsumoan.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button size="lg" className="rounded-full bg-primary hover:bg-primary/90 text-primary-foreground px-8">
                Hasi erosten
              </Button>
              <Button size="lg" variant="outline" className="rounded-full border-background/30 text-background hover:bg-background/10 px-8">
                Denda bat izan nahi duzu?
              </Button>
            </div>
          </div>
        </div>
      </div>

      {/* Main Footer */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-8 lg:gap-12">
          {/* Brand */}
          <div className="col-span-2 md:col-span-1">
            <a href="#" className="flex items-center gap-2 mb-4">
              <div className="w-10 h-10 rounded-full bg-primary flex items-center justify-center">
                <Leaf className="w-5 h-5 text-primary-foreground" />
              </div>
              <span className="text-xl font-semibold text-background">
                Green<span className="text-primary">Local</span>
              </span>
            </a>
            <p className="text-sm text-background/60 mb-6">
              Mundua zaintzea hemendik hasita. Tokiko merkataritza jasangarria Arrigorriagan.
            </p>
            <div className="flex gap-4">
              <a 
                href="https://instagram.com" 
                target="_blank" 
                rel="noopener noreferrer"
                className="w-10 h-10 rounded-full bg-background/10 flex items-center justify-center hover:bg-background/20 transition-colors"
                aria-label="Instagram"
              >
                <Instagram className="w-5 h-5 text-background" />
              </a>
              <a 
                href="https://tiktok.com" 
                target="_blank" 
                rel="noopener noreferrer"
                className="w-10 h-10 rounded-full bg-background/10 flex items-center justify-center hover:bg-background/20 transition-colors"
                aria-label="TikTok"
              >
                <svg className="w-5 h-5 text-background" viewBox="0 0 24 24" fill="currentColor">
                  <path d="M19.59 6.69a4.83 4.83 0 0 1-3.77-4.25V2h-3.45v13.67a2.89 2.89 0 0 1-5.2 1.74 2.89 2.89 0 0 1 2.31-4.64 2.93 2.93 0 0 1 .88.13V9.4a6.84 6.84 0 0 0-1-.05A6.33 6.33 0 0 0 5 20.1a6.34 6.34 0 0 0 10.86-4.43v-7a8.16 8.16 0 0 0 4.77 1.52v-3.4a4.85 4.85 0 0 1-1-.1z"/>
                </svg>
              </a>
            </div>
          </div>

          {/* Links */}
          <div>
            <h4 className="text-sm font-semibold text-background mb-4">Plataforma</h4>
            <ul className="space-y-3">
              <li>
                <a href="#" className="text-sm text-background/60 hover:text-background transition-colors">
                  Dendak arakatu
                </a>
              </li>
              <li>
                <a href="#" className="text-sm text-background/60 hover:text-background transition-colors">
                  Nola funtzionatzen du
                </a>
              </li>
              <li>
                <a href="#" className="text-sm text-background/60 hover:text-background transition-colors">
                  Prezioak
                </a>
              </li>
              <li>
                <a href="#" className="text-sm text-background/60 hover:text-background transition-colors">
                  GreenLocal zigilua
                </a>
              </li>
            </ul>
          </div>

          <div>
            <h4 className="text-sm font-semibold text-background mb-4">Enpresa</h4>
            <ul className="space-y-3">
              <li>
                <a href="#" className="text-sm text-background/60 hover:text-background transition-colors">
                  Guri buruz
                </a>
              </li>
              <li>
                <a href="#" className="text-sm text-background/60 hover:text-background transition-colors">
                  Taldea
                </a>
              </li>
              <li>
                <a href="#" className="text-sm text-background/60 hover:text-background transition-colors">
                  Elikagaien Bankua
                </a>
              </li>
              <li>
                <a href="#" className="text-sm text-background/60 hover:text-background transition-colors">
                  Jasangarritasuna
                </a>
              </li>
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h4 className="text-sm font-semibold text-background mb-4">Kontaktua</h4>
            <ul className="space-y-3">
              <li className="flex items-start gap-2">
                <MapPin className="w-4 h-4 text-primary mt-0.5 shrink-0" />
                <span className="text-sm text-background/60">
                  Arrigorriaga, Bizkaia
                </span>
              </li>
              <li className="flex items-start gap-2">
                <Mail className="w-4 h-4 text-primary mt-0.5 shrink-0" />
                <a href="mailto:kaixo@greenlocal.eus" className="text-sm text-background/60 hover:text-background transition-colors">
                  kaixo@greenlocal.eus
                </a>
              </li>
              <li className="flex items-start gap-2">
                <Phone className="w-4 h-4 text-primary mt-0.5 shrink-0" />
                <a href="tel:+34600000000" className="text-sm text-background/60 hover:text-background transition-colors">
                  +34 600 000 000
                </a>
              </li>
            </ul>
          </div>
        </div>
      </div>

      {/* Bottom Bar */}
      <div className="border-t border-background/10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="flex flex-col md:flex-row justify-between items-center gap-4">
            <div className="flex flex-col sm:flex-row items-center gap-2 sm:gap-4">
              <p className="text-sm text-background/60">
                © 2026 Green Local. Eskubide guztiak gordeta.
              </p>
              <span className="hidden sm:inline text-background/30">•</span>
              <p className="text-sm text-background/60">
                Kooperatiba Txikia
              </p>
            </div>
            <div className="flex items-center gap-6">
              <a href="#" className="text-sm text-background/60 hover:text-background transition-colors">
                Pribatutasuna
              </a>
              <a href="#" className="text-sm text-background/60 hover:text-background transition-colors">
                Lege-oharra
              </a>
              <a href="#" className="text-sm text-background/60 hover:text-background transition-colors">
                Cookieak
              </a>
            </div>
          </div>
        </div>
      </div>

      {/* Credits */}
      <div className="bg-background/5 py-4">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <p className="text-center text-xs text-background/40">
            Oier Perez, Aingeru Gonzalez, Eder Marey eta Uztai Aierdi-k sortua • IES Arrigorriaga BHI • Egin eta Ekin 2025-2026
          </p>
        </div>
      </div>
    </footer>
  )
}
